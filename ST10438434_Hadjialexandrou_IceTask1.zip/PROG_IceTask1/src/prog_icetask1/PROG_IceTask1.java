package prog_icetask1;

import java.util.Scanner;

public class PROG_IceTask1 {

    public static void main(String[] args) {

        int houseNum;
        String streetName;
        String cityName;
        int areaCode;

        try (Scanner sc = new Scanner(System.in)) {

            System.out.println("Enter street name:");
            streetName = sc.nextLine();
            System.out.println("Enter city name:");
            cityName = sc.nextLine();
            System.out.println("Enter house number:");
            houseNum = sc.nextInt();
            System.out.println("Enter area code:");
            areaCode = sc.nextInt();
            sc.close();
        }

        System.out.println("Your address: \t" + houseNum + " " + streetName + "\n\t\t"
                + cityName + "\n\t\t" + areaCode);
    }

}
